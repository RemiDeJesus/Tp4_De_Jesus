extern int open_printer(void);
extern void close_printer(void);
void add_printer_line(unsigned char *bytes, int length);
extern int vquality,hquality;
extern int head_mask;

