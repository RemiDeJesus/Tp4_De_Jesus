# TP 5 environnement de développement 
Matériel pour le TP

* debug : répertoire pour l'exercice sur valgrind
* pdf2html : répertoire pour l'exercice sur le Makefile
* trombi : photo pour le script
